# Đại số tuyến tính, Giải tích nhiều biến và Ứng dụng hiện đại — bản diễn giải tiếng Việt

Mã nguồn LaTeX của bản diễn giải tiếng Việt giáo trình Math 51 (Stanford), chương 1–27,
kèm Phụ lục A (thuật ngữ Anh–Việt), Phụ lục B (lời giải chi tiết) và Phụ lục C (chứng minh bổ sung).

## Biên dịch

Bắt buộc dùng **XeLaTeX** (vì dùng `unicode-math`, `polyglossia` và phông Unicode).
Chạy **hai lần** để mục lục, tham chiếu chéo và liên kết được cập nhật:

```bash
xelatex main.tex
xelatex main.tex
```

Hoặc dùng latexmk:

```bash
latexmk -xelatex main.tex
```

Trên Overleaf: Menu → Settings → Compiler → chọn **XeLaTeX**, Main document → `main.tex`.

## Yêu cầu

- TeX Live 2022 trở lên (đã thử với TeX Live 2023), hoặc MiKTeX bản mới.
- Gói: `amsmath, amssymb, mathtools, unicode-math, polyglossia, geometry, xcolor, graphicx,
  float, enumitem, booktabs, array, tabularx, tikz, tikz-3dplot, pgfplots, tcolorbox, titlesec,
  fancyhdr, caption, hyperref, needspace`.
  (Trên Debian/Ubuntu: `sudo apt install texlive-xetex texlive-latex-extra texlive-pictures texlive-science texlive-lang-other fonts-lmodern fonts-dejavu`.)
- Phông: **Latin Modern** (Roman, Sans, Math) và **DejaVu Sans** (chỉ dùng cho ký hiệu ✓).

## Cấu trúc tệp

| Tệp | Nội dung |
|---|---|
| `main.tex` | Tệp chính: thứ tự các phần, chương, phụ lục |
| `preamble.tex` | Gói, phông, màu, các hộp (định nghĩa, định lý, ví dụ, cẩn thận!…), macro |
| `bia.tex` | Trang bìa |
| `ch0.tex` | Lời mở đầu |
| `ch1.tex` – `ch7.tex` | Phần I. Hình học của vectơ và phép chiếu |
| `ch8.tex` – `ch12.tex` | Phần II. Hàm nhiều biến và tối ưu hóa |
| `ch13.tex` – `ch18.tex` | Phần III. Hình học và đại số của ma trận |
| `ch19.tex` – `ch22.tex` | Phần IV. Đại số ma trận nâng cao và hệ phương trình tuyến tính |
| `ch23.tex` – `ch27.tex` | Phần V. Giá trị riêng và đạo hàm riêng cấp hai |
| `phuluc.tex` | Phụ lục A (thuật ngữ) và khung Phụ lục B |
| `lg1.tex` – `lg5.tex` | Lời giải chi tiết bài tập, theo từng phần |
| `phuluc_cm.tex` | Phụ lục C. Các chứng minh bổ sung |
| `main.pdf` | Bản PDF đã biên dịch sẵn |

Mọi hình vẽ đều vẽ bằng TikZ/pgfplots ngay trong mã nguồn, không cần tệp ảnh ngoài.

## Một số macro hữu ích (trong `preamble.tex`)

- `\vb{x}` vectơ in đậm; `\R` tập số thực; `\nrm{x}` chuẩn; `\cv{...}` / `\scv{...}` vectơ cột thường / nhỏ.
- Hộp: `dinhnghia`, `dinhly`, `vidu` (cú pháp `\begin{dinhly}{Tiêu đề}{nhãn}`, tham chiếu `\ref{dl:nhãn}`),
  `nhaclai`, `canhbao`, `hinhdung`, `ungdung`, `tomtat`, `muctieu`.
- Bài tập: `\baitap` mở mục bài tập, `\bt` đánh số bài; lời giải dùng `\baigiai{chương}{số}` và `\dapso{...}`
  (đề và lời giải tự liên kết với nhau).
- `\buoc{n}` ghi "Bước n."; `\xemcm{nhãn}{mục}` dẫn tới chứng minh ở Phụ lục C.

Bản quyền nội dung gốc thuộc Khoa Toán, Đại học Stanford; đây là bản diễn giải nhằm mục đích học tập.
